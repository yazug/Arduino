/*

 Uses I2c Wires interface

 Uses Analog pin 4 - SDA
 Uses Analog pin 5 - SCL


 Usage:

 */

#if ARDUINO >= 100
#include <Arduino.h>
#else
#include <WProgram.h>
#endif
#include <Wire.h>
#include "ST7032iLCD.h"

#define CMDDELAY 50        // Delay to wait after sending commands;
#define DATADELAY 50        // Delay to wait after sending data;
#define DEFAULTCONTRAST  36

#define LCDI2C_MAX_STRLEN			40
#define LCDI2C_PRINT_STR_DELAY		50
/*
 static unsigned char icon_data[]={
 0x00, 0b10000,
 0x02, 0b10000,
 0x04, 0b10000,
 0x06, 0b10000,

 0x07, 0b10000,
 0x07, 0b01000,
 0x09, 0b10000,
 0x0B, 0b10000,

 0x0D, 0b01000,
 0x0D, 0b00100,
 0x0D, 0b00010,
 0x0D, 0b10000,

 0x0F, 0b10000, //
 };
 */

//stuff the library user might call---------------------------------
//constructor.  num_lines must be 1, 2, 3, or 4 currently.
ST7032iLCD::ST7032iLCD(byte pin) {
//	id = 0;
	rows = 2;
	columns = 16;
	position = 0;
	i2c_address = I2C_ADDRESS;
	contrast = DEFAULTCONTRAST;

	pin_bklight = pin;
}

void ST7032iLCD::initST7032i() {
//	delay(40);
	command(0b00111000); //function set
	command(0b00111001); // function set 
	delay(2);

	command(0b00010100); // interval osc
	command(0b01110000 | (contrast & 0xf)); // contrast Low 4 bits
	delay(2);

	command(0b01011100 | ((contrast >> 4) & 0x3)); // contast High/icon/power
	command(0b01101100); // follower control
	delay(300);

	command(0b00111000); // function set
	command(0b00001100); // Display On
	delay(2);

	command(0b00000001); // Clear Display
	delay(2); // Clear Display needs additional wait
	command(0b00000010); // home, but does not woek
	delay(2);

	pinMode(pin_bklight, OUTPUT);
}

//	Send a command to the display that is not supported

void ST7032iLCD::send(uint8_t c, uint8_t mode) {
	// LOW -- command, HIGH -- data.
	long tdelay;
	Wire.beginTransmission(i2c_address);
#if ARDUINO >= 100
	if (mode == HIGH) {
		Wire.write(1 << 6);
		tdelay = DATADELAY;
	} else {
		Wire.write((uint8_t) 0x00);
		tdelay = CMDDELAY;
	}
#else
	if (mode == HIGH) {
		Wire.send(1 << 6);
		tdelay = DATADELAY;
	} else {
		Wire.send(0x00);
		tdelay = CMDDELAY;
	}
#endif
#if ARDUINO >= 100
	Wire.write(c);
#else
	Wire.send(c);
#endif
	Wire.endTransmission();
	delayMicroseconds(tdelay);
}


#if ARDUINO >= 100
size_t ST7032iLCD::write(uint8_t c)
#else
		void ST7032iLCD::write(uint8_t c)
#endif
		{
	if (c == (uint8_t) '\n') {
		wrap();
		return 1;
	}
	send(c, HIGH);
	position++;
	if (position % 0x40 > 0x27) {
		wrap();
	}
#if ARDUINO >= 100
	return 1;
#endif
}

void ST7032iLCD::wrap() {
	if (position < 0x40)
		position = 0x40;
	else
		position = 0;
	command(0b10000000 | position);
}

//send the clear screen command to the LCD
/*
void ST7032iLCD::clear() {
	command(0b00000001); // Clear Display
	delay(2);
}

//send the Home Cursor command to the LCD      ********** Not Working ***************

void ST7032iLCD_::home() {
//	command(0b00000010);
	setCursor(0, 0); // The command to home the cursor does not work on the version of the dislay I have
// So we do it this way.
}
*/

//Turn the LCD ON

void ST7032iLCD::on() {
	send(0b00111000, LOW); // function set
	send(0b00001100, LOW); // Display On
}

// Turn the LCD OFF
/*
 void i2cLCD::off(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x0B);
 Wire.endTransmission();
 delay(CMDDELAY);

 }


 //Turn the Underline Cursor ON

 void i2cLCD::cursor_on(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x0E);
 Wire.endTransmission();
 delay(CMDDELAY);

 }
 */

//Turn the Underline  Cursor OFF
/*
 void i2cLCD::cursor_off(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x0F);
 Wire.endTransmission();
 delay(CMDDELAY);

 }
 */

//Turn the Underline Cursor ON
/*
 void i2cLCD::blink_on(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x12);
 Wire.endTransmission();
 delay(CMDDELAY);

 }
 */

//Turn the Underline  Cursor OFF
/*
 void i2cLCD::blink_off(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x13);
 Wire.endTransmission();
 delay(CMDDELAY);

 }
 */

//Move the cursor left 1 space
/*
 void i2cLCD::left(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x10);
 Wire.endTransmission();
 delay(CMDDELAY);

 }
 */

//Move the cursor right 1 space
/*
 void i2cLCD::right(){

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x11);
 Wire.endTransmission();
 delay(CMDDELAY);

 }
 */

// initiatize lcd after a short pause
//while there are hard-coded details here of lines, cursor and blink settings, you can override these original settings after calling .init()
/*
 void i2cLCD::init () {

 Wire.begin();
 delay(40);
 i2c_command(0b00111000); //function set
 i2c_command(0b00111001); // function set

 i2c_command(0b00010100); // interval osc
 i2c_command(0b01110000 | (contrast & 0x0f)); // contrast Low

 i2c_command(0b01011100 | ((contrast >> 4) & 0x3)); // contast High/icon/power
 i2c_command(0b01101100); // follower control
 delay(300);

 i2c_command(0b00111000); // function set
 i2c_command(0b00001100); // Display On

 i2c_command(0b00000001); // Clear Display
 delay(2);		 // Clear Display needs additional wait
 //	on();
 //     clear();
 //      blink_off();
 //      cursor_off();
 //      home();
 cursorPosC = 0;
 cursorPosR = 0;

 }
 */

void ST7032iLCD::setCursor(uint8_t c, uint8_t r) {
	position = (r % rows) * 0x40 + (c % 0x27);
	command(0b10000000 | position);
}


/*
 unsigned char i2cLCD::init_bargraph(unsigned char graphtype)
 {
 switch (graphtype)
 {
 case i2cLCD_VERTICAL_BAR_GRAPH:
 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x18);
 Wire.endTransmission();
 break;
 case i2cLCD_HORIZONTAL_BAR_GRAPH:
 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x16);
 Wire.send(0x00);
 Wire.endTransmission();
 break;
 case i2cLCD_HORIZONTAL_LINE_GRAPH:
 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x16);
 Wire.send(0x01);
 Wire.endTransmission();
 break;
 default:
 return 1;
 }

 return 0;
 }
 */
/*
 void i2cLCD::draw_horizontal_graph(unsigned char row, unsigned char column, unsigned char len,  unsigned char pixel_col_end)
 {
 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x17);
 Wire.send(row);
 Wire.send(column);
 Wire.send(len);
 Wire.send(pixel_col_end);
 Wire.endTransmission();
 }
 */
/*
 void i2cLCD::draw_vertical_graph(unsigned char row, unsigned char column, unsigned char len,  unsigned char pixel_row_end)
 {
 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x19);
 Wire.send(row);
 Wire.send(column);
 Wire.send(len);
 Wire.send(pixel_row_end);
 Wire.endTransmission();
 }
 */
/*
 void i2cLCD::load_custom_character(unsigned char char_num, unsigned char *rows)
 {
 unsigned char i;

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x1A);
 Wire.send(char_num);
 for (i = 0; i < i2cLCD_CUSTOM_CHAR_SIZE; i++)
 Wire.send(rows[i]);
 Wire.endTransmission();
 }
 */
/*
 unsigned char i2cLCD::set_backlight_brightness(unsigned char new_val)
 {
 if ((new_val < i2cLCD_MIN_BRIGHTNESS)
 || (new_val > i2cLCD_MAX_BRIGHTNESS))
 return i2cLCD_VALUE_OUT_OF_RANGE;

 Wire.beginTransmission(i2caddress);
 Wire.send(0xFE);
 Wire.send(0x03);
 Wire.send(new_val);
 Wire.endTransmission();
 return 0;
 }
 */

void ST7032iLCD::setContrast(char val) {
	contrast = 0x7f & val;
	command(0b00111000); //function set
	command(0b00111001); // function set
	delay(2);
	command(0b01110000 | (contrast & 0xf)); // contrast Low 4 bits
	delay(2);
	command(0b01011100 | ((contrast >> 4) & 0x3)); // contast High/icon/power
	command(0b00111000); // function set
	delay(2);
}

