#ifndef ST7032iLCD_h
#define ST7032iLCD_h

#include <inttypes.h>
#if ARDUINO >= 100
#include <Arduino.h>
#else
#include <WProgram.h>
#endif
#include <Print.h>
#include "LCD.h"

#define I2C_ADDRESS 0b0111110

class ST7032iLCD: public LCD {
	char rows, columns;
	char position, contrast;
//	int id;
	byte i2c_address;
	byte pin_bklight;
//	TwoWire twowire;

	void initST7032i();

public:
//	i2cLCD(TwoWire);
	ST7032iLCD(byte pin = 0xff);

	void begin(int c = 16, int r = 2) {
		initST7032i();
	}
	inline void init() {
		initST7032i();
		home();
	}

	virtual void send(uint8_t, uint8_t);
	// virtual void command(byte);
	virtual size_t write(byte);

	/*
	 #if ARDUINO >= 100
	 virtual size_t write(uint8_t);
	 virtual size_t println(void) { wrap(); return 1; }
	 #else
	 virtual void write(uint8_t);
	 virtual void println(void) { wrap(); }
	 #endif
	 */
	 void wrap();
	 /*
	 void clearLine();

	 void clear();
	 void home();
*/	 void setCursor(uint8_t, uint8_t);

	 void on();
	 void off();
	 void setContrast(char );

	 void backlightOn() { digitalWrite(pin_bklight, LOW); }
	 void backlightOff() { digitalWrite(pin_bklight, HIGH); }

};

#endif
