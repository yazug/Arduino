/* 
 NOTE: you must: #include <SoftwareSerial.h>
 BEFORE including the class header file
 
 allen joslin
 payson productions
 allen@joslin.net
 */

#ifndef SerLCD_h
#define SerLCD_h

#if ARDUINO >= 100
	#include <Arduino.h>
#else
	#include <WProgram.h>
#endif

#include <Print.h>
#include <LiquidCrystal.h>
#include <SoftwareSerial.h>

/******************************************************************************************************/
/* SparkFunSerLCD -- manages the SparkFun SerLCD, based on SoftwareSerial to aid pinning and printing */
/*                                                                                                    */
/*     some cmds are cached so repeated calls will not actually be sent which can cause               */
/*     flickering of the display, printed values are not cached and are always sent                   */
/*                                                                                                    */
/*     autoOn: turn off the display and turn it back on with the next command                         */
/*                                                                                                    */
/*     posBase: cursor positioning via 0x0 or 1x1                                                     */
/*                                                                                                    */
/*     on/off: display of characters, not backlight                                                   */
/*                                                                                                    */
/*     bright: backlight control, by percentage                                                       */
/*                                                                                                    */
/*     scrolling: scrolling is slow because of the amount of time the LCD takes to redraw.            */
/*     scrolling is persistant and moves the x-origin a single column at a time                       */
/*                                                                                                    */
/******************************************************************************************************/


class SerLCD : public Print {

	SoftwareSerial serport;
	long baud;
//	uint8_t lastBright;
	uint8_t cursorRow, cursorColumn;
	int bounceDelay;
	uint8_t portpin;
	
	uint8_t _displayfunction;
	uint8_t _displaycontrol;
	uint8_t _displaymode;
	uint8_t _numlines, _numcolumns;
	
public:
	SerLCD(uint8_t pin);
	void begin (long speed, uint8_t cols = 16, uint8_t rows = 2, uint8_t charsize = LCD_5x8DOTS); 

	void send(uint8_t, uint8_t);
	void command(uint8_t value);
	virtual size_t write(uint8_t value);
		
	void clear();
	void home();
	void setCursor(uint8_t, uint8_t);
	
	void brightness ( int level );
	void backlightOn(int val = 100) { brightness(val*10/34); }
	void backlightOff() { brightness(0); }
	/*
	void printNumberFormatted(unsigned long, uint8_t, uint8_t, uint8_t);
	*/
	void noDisplay();
	void display();
	void noBlink();
	void blink();
	void noCursor();
	void cursor();
	void scrollDisplayLeft();
	void scrollDisplayRight();
	void leftToRight();
	void rightToLeft();
	void autoscroll();
	void noAutoscroll();
	
	void createChar(uint8_t, uint8_t[]);
	
};


#endif
