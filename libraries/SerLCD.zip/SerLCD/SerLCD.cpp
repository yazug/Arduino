/* 
 NOTE: you must: #include "SoftwareSerial.h"
 BEFORE including the class header file
 
 allen joslin
 payson productions
 allen@joslin.net
 */
#if ARDUINO >= 100
	#include <Arduino.h>
#else
	#include <WProgram.h>
#endif
//#include <inttypes.h>
#include <SoftwareSerial.h>
#include "SerLCD.h"


/* ======================================================== */

//--------------------------
SerLCD::SerLCD (uint8_t pin) 
			: serport(pin, pin) { 
	// desired pin, rows, cols
//	if (/* fourbitmode */ 1)
		
	_displayfunction = LCD_4BITMODE; // | LCD_1LINE; // | LCD_5x8DOTS;
//	else 
//	_displayfunction = LCD_8BITMODE | LCD_1LINE; // | LCD_5x8DOTS;

	_numlines = 1;
	_numcolumns = 16;

	portpin = pin;
	bounceDelay = 4;
}

//--------------------------
void SerLCD::begin(long speed,uint8_t cols, uint8_t lines, uint8_t dotsize ) {
	pinMode(portpin, OUTPUT);
	delay(bounceDelay);
	switch (speed) {
		case 2400:
		case 4800:
		case 9600:
		case 14400:
		case 19200:
		case 38400:
			baud = speed;
			break;
		default:
			baud = 9600;
			break;
	}
	serport.begin(baud);
	delay(bounceDelay);
	
	_numcolumns = cols;
	_numlines = lines;
	if (lines > 1) {
		_displayfunction |= LCD_2LINE;
	} else {
		_displayfunction |= LCD_1LINE;
	}	
	// for some 1 line displays you can select a 10 pixel high font
	if ((dotsize != 0) && (lines == 1)) {
		_displayfunction |= LCD_5x10DOTS;
	}
	
	cursorRow = 0;
	cursorColumn = 0;
	
	// finally, set # lines, font size, etc.
	command(LCD_FUNCTIONSET | _displayfunction);  
	
	// turn the display on with no cursor or blinking default
	_displaycontrol = LCD_DISPLAYON | LCD_CURSOROFF | LCD_BLINKOFF;  
	display();
	
	// clear it off
	clear();
	
	// Initialize to default text direction (for romance languages)
	_displaymode = LCD_ENTRYLEFT | LCD_ENTRYSHIFTDECREMENT;
	// set the entry mode
	command(LCD_ENTRYMODESET | _displaymode);

	//------
//	lastBright = brtness;
	backlightOn();
	noCursor();
}

void SerLCD::send(uint8_t c, uint8_t mode) {
	if (mode == HIGH) {
		switch (c) {
			case '\r':
				setCursor(0, cursorRow);
				break;
			case '\n':
				setCursor(0, ++cursorRow % _numlines);
				break;
			default:
				serport.write((byte)c);
				cursorColumn++;
				break;
		}
	} else {
		serport.write((byte)0xfe);
		delay(bounceDelay); 
		serport.write((byte)c);
		delay(bounceDelay); 
	}
}

/*********** mid level commands, for sending data/cmds */

void SerLCD::command(uint8_t value) {
	send(value, LOW);
}

size_t SerLCD::write(uint8_t value) {
	send(value, HIGH);
	return 1;
}

/********** high level commands, for the user! */
void SerLCD::clear()
{
	SerLCD::command(LCD_CLEARDISPLAY);  // clear display, set cursor position to zero
	cursorRow = 0;
	cursorColumn = 0;
	delay(5);  // this command takes a long time!
}

void SerLCD::home()
{
	
	SerLCD::command(LCD_RETURNHOME);  // set cursor position to zero
	 cursorRow = 0;
	 cursorColumn = 0;
	delay(5);  // this command takes a long time!
	
	//setCursor(0, 0);
}

void SerLCD::setCursor(uint8_t col, uint8_t row)
{
	int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
	if ( row > _numlines ) {
		row = _numlines-1;    // we count rows starting w/0
	}
	SerLCD::command(LCD_SETDDRAMADDR | (col + row_offsets[row]));
	cursorRow = row;
	cursorColumn = col;
}



//--------------------------
void SerLCD::brightness ( int brt ) {
//	if (lastBright == brt) { return; }
	brt = max(0,brt);
	brt = min(brt,29);
//	lastBright = brt;
	print((char)0x7c);
	delay(200); 
	print((char)128+brt);
	delay(200); 
}

/********** high level commands, for the user! */
/*
void LiquidCrystal::clear()
{
	command(LCD_CLEARDISPLAY);  // clear display, set cursor position to zero
	delayMicroseconds(2000);  // this command takes a long time!
}

void LiquidCrystal::home()
{
	command(LCD_RETURNHOME);  // set cursor position to zero
	delayMicroseconds(2000);  // this command takes a long time!
}

void LiquidCrystal::setCursor(uint8_t col, uint8_t row)
{
	int row_offsets[] = { 0x00, 0x40, 0x14, 0x54 };
	if ( row > _numlines ) {
		row = _numlines-1;    // we count rows starting w/0
	}
	
	command(LCD_SETDDRAMADDR | (col + row_offsets[row]));
}
*/
// Turn the display on/off (quickly)
void SerLCD::noDisplay() {
	_displaycontrol &= ~LCD_DISPLAYON;
	command(LCD_DISPLAYCONTROL | _displaycontrol);
}
void SerLCD::display() {
	_displaycontrol |= LCD_DISPLAYON;
	command(LCD_DISPLAYCONTROL | _displaycontrol);
}

// Turns the underline cursor on/off
void SerLCD::noCursor() {
	_displaycontrol &= ~LCD_CURSORON;
	command(LCD_DISPLAYCONTROL | _displaycontrol);
}
void SerLCD::cursor() {
	_displaycontrol |= LCD_CURSORON;
	command(LCD_DISPLAYCONTROL | _displaycontrol);
}

// Turn on and off the blinking cursor
void SerLCD::noBlink() {
	_displaycontrol &= ~LCD_BLINKON;
	command(LCD_DISPLAYCONTROL | _displaycontrol);
}
void SerLCD::blink() {
	_displaycontrol |= LCD_BLINKON;
	command(LCD_DISPLAYCONTROL | _displaycontrol);
}

// These commands scroll the display without changing the RAM
void SerLCD::scrollDisplayLeft(void) {
	command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVELEFT);
}
void SerLCD::scrollDisplayRight(void) {
	command(LCD_CURSORSHIFT | LCD_DISPLAYMOVE | LCD_MOVERIGHT);
}

// This is for text that flows Left to Right
void SerLCD::leftToRight(void) {
	_displaymode |= LCD_ENTRYLEFT;
	command(LCD_ENTRYMODESET | _displaymode);
}

// This is for text that flows Right to Left
void SerLCD::rightToLeft(void) {
	_displaymode &= ~LCD_ENTRYLEFT;
	command(LCD_ENTRYMODESET | _displaymode);
}

// This will 'right justify' text from the cursor
void SerLCD::autoscroll(void) {
	_displaymode |= LCD_ENTRYSHIFTINCREMENT;
	command(LCD_ENTRYMODESET | _displaymode);
}

// This will 'left justify' text from the cursor
void SerLCD::noAutoscroll(void) {
	_displaymode &= ~LCD_ENTRYSHIFTINCREMENT;
	command(LCD_ENTRYMODESET | _displaymode);
}

// Allows us to fill the first 8 CGRAM locations
// with custom characters
void SerLCD::createChar(uint8_t location, uint8_t charmap[]) {
	location &= 0x7; // we only have 8 locations 0-7
	command(LCD_SETCGRAMADDR | (location << 3));
	for (int i=0; i<8; i++) {
		write(charmap[i]);
	}
}


/* ======================================================== */

//
/*
void SerLCD::printNumberFormatted(unsigned long val, uint8_t base, uint8_t digits, uint8_t point) {
	unsigned long d = 1;
	uint8_t n;
	for (int i = 1; i < digits; i++)
		d = d * base;
	for ( ; digits - point > 0; d = d / base, digits--) {
		n = val/d % base;
		print(n, base);
	}
	if ( point == 0 )
		return;
	print('.');
	for ( ; digits > 0; d = d / base, digits--) {
		n = val/d % base;
		print(n, base);
	}	
}
 */
//
