#include <avr/pgmspace.h>

#include <WProgram.h>
#include <Wire.h>

#include "SL0i2c.h"

SL0i2c::SL0i2c(byte addr, byte tag_pin, byte wakeup_pin) {
  address = addr;
  pin_tag = tag_pin;
  pin_input = wakeup_pin;
}

void SL0i2c::init() {
  card.type = 0;
  card.uid_length = 0;
  packet.status = 0;
  if ( pin_tag != 0xff )
    pinMode(pin_tag, INPUT);
//  event_millis = millis();
//  event_wait = 20;
}

void SL0i2c::send_command(byte cmd, byte len) {
	packet.length = len + 1;
	packet.command = cmd;
	transmit();
}

void SL0i2c::transmit() {
	// wait until at least 20ms passed since last I2C transmission
//	while(t > millis());
//	t = millis() + 20;

  // transmit packet with checksum
  Wire.beginTransmission(address);
  Wire.send(packet.length);
  Wire.send(packet.command);
  packet.length--;
  for (int i = 0; i < packet.length; i++) {
    Wire.send(packet.data[i]);
  }
  Wire.endTransmission();
}

byte SL0i2c::receive(byte len) {
  // wait until at least 20ms passed since last I2C transmission
  //	while(t > millis());
  //	t = millis() + 20;
  int i = 0;
  byte * p = &packet.length;
  len += 3;
  // read response
  do {
    Wire.requestFrom(address, len);
    delay(5);
    i++;
  } while (i < 7 && Wire.available() == 0);
  if ( Wire.available() > 0 ) {
    // get length	of packet
    *p++ = Wire.receive(); // pakcet.length
    *p++ = Wire.receive();
    packet.length--;
    *p++ = Wire.receive();
    packet.length--;
    // get data
    for (i = 0; i < packet.length; i++) {
      *p++ = Wire.receive();
    }
    // return with length of response
    return packet.length;
  }
  return 0;
}

boolean SL0i2c::select() {
  byte i;
  send_command(CMD_SELECT);
  delay(20);
  receive(8);
  if ( packet.status != Operation_succeed ) {
    card.type = 0;
    card.uid_length = 0;
    return false;
  }
  card.uid_length = packet.length - 1;
  for (i = 0; i < card.uid_length; i++) 
    card.uid[i] = packet.data[i];
  card.type = packet.data[i++];
  for ( ; i < UID_MAXLENGTH; i++)
    card.uid[i] = 0;
  return packet.status == Operation_succeed;
}


char* SL0i2c::type_name(char * buf) { 
  PROGMEM const static prog_char names[] = 
    "\0Standard 1k\0Pro\0UltraLight\0Standard 4k\0ProX\0DesFire\0\0\0\0\0Unknown";
  int i, p;
  for ( i = 0, p = 0; i < card.type; p++) {
    if ( pgm_read_byte(names + p) == 0 )
      i++;
  }
  strcpy_P(buf, names+p);
  return buf;
}

boolean SL0i2c::set_led(const byte onoff) {
  packet.data[0] = (byte)(onoff != 0);
  send_command(CMD_SET_LED,1);
  delay(20);
  receive(0);
  return packet.status == Operation_succeed;
}


boolean SL0i2c::login_sector(const byte sec, const byte * typekey) {
  byte *p = packet.data;
  *p++ = sec;
  memcpy(p, typekey, 7);
  send_command(CMD_LOGIN, 8);
  delay(20);
  receive(0);
  return packet.status == Login_succeed;
}

boolean SL0i2c::write_master_key(const byte sec, const byte * typekey) {
  byte *p = packet.data;
  *p++ = sec;
  if ( *typekey != 0xAA ) {
	packet.status = 0x0C; // as load-key-failure
  } else {
	memcpy(p, typekey+1, 6);
	send_command(CMD_WRITE_KEY, 7);
	delay(20);
	receive(6);
  }
  return packet.status == Operation_succeed;
}



boolean SL0i2c::read_block(byte baddr, byte blk[]) {
  packet.data[0] = baddr;
  send_command(CMD_READ16, 1);
  delay(20);
  receive(16);
  memcpy((void*) blk, (void*) packet.data, 16);
  return packet.status == Operation_succeed;
}

boolean SL0i2c::write_block(byte baddr, const byte blk[]) {
  packet.data[0] = baddr;
  memcpy((void*) (packet.data+1), (void*) blk, 16);
  send_command(CMD_WRITE16, 17);
  delay(30);
  receive(16);
  return packet.status == Operation_succeed;
}

boolean SL0i2c::read_value(byte baddr, long & lval) {
  packet.data[0] = baddr;
  send_command(CMD_READ_VALUE, 1);
  delay(20);
  receive(4);
  lval = *((long*) packet.data);
  return packet.status == Operation_succeed;
}

boolean SL0i2c::manipulate_value(byte cmd, byte baddr, long & lval) {
  packet.data[0] = baddr;
  memcpy((void*) (packet.data+1), (void*) &lval, 4);
  send_command(cmd, 5);
  delay(20);
  receive(4);
  lval = *((long*)packet.data);
  return packet.status == Operation_succeed;
}

boolean SL0i2c::copy_value(byte addra, byte addrb) {
  packet.data[0] = addra;
  packet.data[1] = addrb;
  send_command(CMD_COPY_VALUE, 2);
  delay(20);
  receive(4);
  return packet.status == Operation_succeed;
}

boolean bitAt(byte a[], int pos) {
  return a[pos>>3]>>(pos & 0b111) & 1;
}

byte SL0i2c::access_condition(byte sec, byte acc[4]) {
   byte accBytes[6];
   read_block((sec<<2)+3, packet.data);
   memcpy(accBytes, packet.data + 6, 4);
   for(int i = 0; i < 4; i++)
	acc[i] = 0;
   for(int i = 0; i < 4; i++) {
	for(int j = 0; j < 4; j++) {
	   acc[i] |= (accBytes[1+(j>>1)] & (1<<(i+4*(j%1))) ? 1 : 0 )<<j;
	}
  return packet.status == Operation_succeed;
}

