#ifndef	SL0i2c_h
#define	SL0i2c_h

#include "WProgram.h"

class SL0i2c {
   // constants 
private:
   static const byte CMD_IDLE		= 0x00;
   static const byte CMD_SELECT		= 0x01;
   static const byte CMD_LOGIN		= 0x02;
   static const byte	CMD_READ16      = 0x03;
   static const byte	CMD_WRITE16		= 0x04;
   static const byte	CMD_READ_VALUE  = 0x05;
   static const byte	CMD_WRITE_VALUE = 0x06;
   static const byte	CMD_WRITE_KEY	= 0x07;
   static const byte	CMD_INC_VALUE	= 0x08;
   static const byte	CMD_DEC_VALUE	= 0x09;
   static const byte	CMD_COPY_VALUE	= 0x0A;
   static const byte	CMD_READ4		= 0x10;
   static const byte	CMD_WRITE4		= 0x11;
   static const byte CMD_SEEK		= 0x20;
   static const byte CMD_SET_LED		= 0x40;
   static const byte	CMD_SLEEP		= 0x50;
   static const byte	CMD_RESET		= 0xFF;
   
   static const byte	OK				= 0x00;
   static const byte	NO_TAG			= 0x01;
   static const byte	LOGIN_OK		= 0x02;
   static const byte	LOGIN_FAIL		= 0x03;
   static const byte	READ_FAIL		= 0x04;
   static const byte	WRITE_FAIL		= 0x05;
   static const byte	CANT_VERIFY		= 0x06;
   static const byte	COLLISION		= 0x0A;
   static const byte	KEY_FAIL		= 0x0C;
   static const byte	NO_LOGIN		= 0x0D;
   static const byte	NO_VALUE		= 0x0E;
   //
   static const byte Operation_succeed   = 0x00;
   static const byte No_tag              = 0x01;
   static const byte Login_succeed       = 0x02;
   static const byte Login_fail          = 0x03;
   static const byte Read_fail           = 0x04;
   static const byte Write_fail          = 0x05;
   static const byte Unable_to_read_after_write = 0x06;
   static const byte Address_overflow    = 0x08;
   static const byte Not_authenticate    = 0x0D;
   static const byte Not_a_value_block   = 0x0E;
   static const byte Checksum_error      = 0xF0;
   static const byte Command_code_error  = 0xF1;
   
   
public:
   static const byte MIFARE_1K         = 1;
   static const byte MIFARE_PRO        = 2;
   static const byte MIFARE_ULTRALIGHT = 3;
   static const byte MIFARE_4K         = 4;
   static const byte MIFARE_PROX       = 5;
   static const byte MIFARE_DESFIRE    = 6;
   
   const static byte UID_MAXLENGTH		= 10;
   const static byte CARDINFO_LENGTH	= UID_MAXLENGTH+2;
   const static byte TYPENAME_MAXLENGTH	= 12;
   
private:
   const static int PACKET_SIZE	= 20;
   
   //
   byte address;
   byte pin_tag;
   byte pin_input;
   
   // card
   struct CardInfo {
	byte uid_length;
	byte uid[UID_MAXLENGTH];
	byte type;
   } card;
   
   struct PacketInfo {
	byte length;
	byte command;
	byte status;
	byte data[PACKET_SIZE-3];
   } packet;
   
   void send_command(byte, byte = 0);
   void transmit();
   byte receive(byte);
   
public:
   const static byte I2C_ADDRESS = 0x50;
   
   SL0i2c(byte addr = I2C_ADDRESS, byte tag_pin = 0xff, byte wakeup_pin = 0xff);
   void init();
   void begin() { init(); }
   
   byte status() { return packet.status; }
   boolean detect() { if (pin_tag == 0xff) return false; return !digitalRead(pin_tag); }
   boolean select();
   byte * uid() { return card.uid; }
   byte uid_length() { return card.uid_length; }
   byte card_type() { return card.type; }
   byte * card_info() { return (byte*) &card; }
   char* type_name(char *);
   void get_uid(byte * buf) { memcpy(buf, card.uid, UID_MAXLENGTH); }
   void get_card_info(byte * buf) { memcpy(buf, (void*) &card, CARDINFO_LENGTH); }
   boolean identical(byte * buf) { return memcmp(buf, (void*) &card, CARDINFO_LENGTH) == 0; }
   boolean set_led(const byte onoff);
   
   boolean login_sector(const byte, const byte *);
   boolean read_block(byte baddr, byte blk[]);
   boolean write_block(byte baddr, const byte blk[]);
   boolean read_value(byte baddr, long & lval);
   //  byte * get_data() { return transdata; }
   long value() { return  *((long*) packet.data); }
   boolean manipulate_value(byte cmd, byte baddr, long & lval);
   byte increment_value(byte baddr, long & lval) { return manipulate_value(CMD_INC_VALUE, baddr, lval); }
   boolean decrement_value(byte baddr, long & lval) { return manipulate_value(CMD_DEC_VALUE, baddr, lval); }
   boolean initialize_value(byte baddr, long & lval) { return manipulate_value(CMD_WRITE_VALUE, baddr, lval); }
   boolean copy_value(byte addra, byte addrb);
   
   boolean write_master_key(const byte sector, const byte * typekey);
   byte access_condition(byte sec, byte acc[4]);
};

#endif
