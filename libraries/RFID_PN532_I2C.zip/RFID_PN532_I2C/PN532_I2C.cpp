/*
 * PN532_I2C.cpp
 *
 *  Created on: 2012/06/30
 *      Author: sin
 */

#include <Wire.h>

#include "PN532_I2C.h"

PN532::PN532(byte addr, byte irq, byte rst) :
		i2c_address(addr), pin_irq(irq), pin_rst(rst) {
	pinMode(pin_irq, INPUT);
	pinMode(pin_rst, OUTPUT);
}

void PN532::init() {
	chksum = 0;
	// Reset the PN532
	digitalWrite(pin_rst, HIGH);
	digitalWrite(pin_rst, LOW);
	delay(400);
	digitalWrite(pin_rst, HIGH);
}

void PN532::send(byte d) {
	twi_write(d);
	chksum += d;
}

void PN532::send(byte a[], byte len) {
	for (; len > 0; len--) {
		chksum += *a;
		twi_write(*a++);
	}
}

// default timeout of one second
boolean PN532::sendCommand(byte cmd, long timeout) {
	// write the command
	send(cmd);
	long swatch = millis() + timeout;

	// Wait for chip to say its ready!
	while (irq_status() != I2C_READY) {
		if (timeout != 0) {
			if (swatch < millis())
				return false;
		}
		delay(10);
	}

#ifdef PN532DEBUG
	Serial.println("IRQ received");
#endif

	// read acknowledgement
//  if (!readackframe()) {
	uint8_t ackbuff[6];
	byte pn532ack[] = {0x00, 0x00, 0xFF, 0x00, 0xFF, 0x00};
	receive(ackbuff, 6);

	if (0 == strncmp((char *) ackbuff, (char *) pn532ack, 6)) {
#ifdef PN532DEBUG
		Serial.println("No ACK frame received!");
#endif
		return false;
	}

	return true; // ack'd command
}


byte PN532::receive(byte *buff, byte n) {
	Wire.requestFrom((int)I2C_ADDRESS, (int) n+2);
	twi_read();
	for(; n > 0; n--) {
		delayMicroseconds(500);
		*buff++ = twi_read();
	}
	return n;
}
/*
void PN532_I2C::wirereaddata(uint8_t* buff, uint8_t n) {
	uint16_t timer = 0;

	delay(2);

#ifdef PN532DEBUG
	Serial.print("Reading: ");
#endif
	// Start read (n+1 to take into account leading 0x01 with I2C)
	Wire.requestFrom(I2C_ADDRESS, (uint8_t)(n + 2));
	// Discard the leading 0x01
	twi_read();
	for (uint8_t i = 0; i < n; i++) {
		delay(1);
		buff[i] = twiread();
#ifdef PN532DEBUG
		Serial.print(" 0x");
		Serial.print(buff[i], HEX);
#endif
	}
	// Discard trailing 0x00 0x00
	// wirerecv();

#ifdef PN532DEBUG
	Serial.println();
#endif
}
*/

byte PN532::irq_status(void) {
	if (digitalRead(pin_irq) == 1)
		return I2C_BUSY;
	else
		return I2C_READY;
}

void PN532::getFirmwareVersion(byte buf[]) {
  uint32_t response;

  if (! sendCommand(COMMAND_GETFIRMWAREVERSION) )
    return;// 0;

  // read data packet
  receive(packetbuffer, 12);

  // check some basic stuff
  byte pn532response_firmwarevers[] = {0x00, 0xFF, 0x06, 0xFA, 0xD5, 0x03};
  if (0 != strncmp((char *)packetbuffer, (char *)pn532response_firmwarevers, 6)) {
    #ifdef PN532DEBUG
    Serial.println("Firmware doesn't match!");
	#endif
    return; // 0;
  }

  buf[0] = packetbuffer[7];
  buf[1] = packetbuffer[8];
  buf[2] = packetbuffer[9];
  buf[3] = packetbuffer[10];
  return;
}
