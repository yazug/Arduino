/*
 * PN532_I2C.h
 *
 *  Created on: 2012/06/30
 *      Author: sin
 */

#ifndef PN532_I2C_H_
#define PN532_I2C_H_

#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif

#include <Wire.h>

class PN532 {

	static const byte I2C_READBIT = (0x01);
	static const byte I2C_BUSY = (0x00);
	static const byte I2C_READY = (0x01);
	static const byte I2C_READYTIMEOUT = (20);

	// PN532 Commands
#define PN532_COMMAND_DIAGNOSE              (0x00)
#define PN532_COMMAND_GETFIRMWAREVERSION    (0x02)
	static const byte COMMAND_GETFIRMWAREVERSION 	=   (0x02);
#define PN532_COMMAND_GETGENERALSTATUS      (0x04)
#define PN532_COMMAND_READREGISTER          (0x06)
#define PN532_COMMAND_WRITEREGISTER         (0x08)
#define PN532_COMMAND_READGPIO              (0x0C)
#define PN532_COMMAND_WRITEGPIO             (0x0E)
#define PN532_COMMAND_SETSERIALBAUDRATE     (0x10)
#define PN532_COMMAND_SETPARAMETERS         (0x12)
#define PN532_COMMAND_SAMCONFIGURATION      (0x14)
#define PN532_COMMAND_POWERDOWN             (0x16)
#define PN532_COMMAND_RFCONFIGURATION       (0x32)
#define PN532_COMMAND_RFREGULATIONTEST      (0x58)
#define PN532_COMMAND_INJUMPFORDEP          (0x56)
#define PN532_COMMAND_INJUMPFORPSL          (0x46)
#define PN532_COMMAND_INLISTPASSIVETARGET   (0x4A)
#define PN532_COMMAND_INATR                 (0x50)
#define PN532_COMMAND_INPSL                 (0x4E)
#define PN532_COMMAND_INDATAEXCHANGE        (0x40)
#define PN532_COMMAND_INCOMMUNICATETHRU     (0x42)
#define PN532_COMMAND_INDESELECT            (0x44)
#define PN532_COMMAND_INRELEASE             (0x52)
#define PN532_COMMAND_INSELECT              (0x54)
#define PN532_COMMAND_INAUTOPOLL            (0x60)
#define PN532_COMMAND_TGINITASTARGET        (0x8C)
#define PN532_COMMAND_TGSETGENERALBYTES     (0x92)
#define PN532_COMMAND_TGGETDATA             (0x86)
#define PN532_COMMAND_TGSETDATA             (0x8E)
#define PN532_COMMAND_TGSETMETADATA         (0x94)
#define PN532_COMMAND_TGGETINITIATORCOMMAND (0x88)
#define PN532_COMMAND_TGRESPONSETOINITIATOR (0x90)
#define PN532_COMMAND_TGGETTARGETSTATUS     (0x8A)

	static const byte PACKBUFFSIZE = 64;
//
	byte pin_irq;
	byte pin_rst;
	byte i2c_address;
	//
	byte chksum;
	byte packetbuffer[PACKBUFFSIZE];
	//

	inline void twi_write(const byte & d) {
		Wire.write(d);
	}

	inline byte twi_read() {
		return Wire.read();
	}

	void send(byte d);
	void send(byte *buf , byte n);
	byte receive(byte * buf, byte n);

	boolean sendCommand(byte cmd, long timeout = 1000);

public:
	static const byte I2C_ADDRESS = (0x48 >> 1);

	PN532(byte addr = I2C_ADDRESS, byte irq = 0xff, byte rst = 0xff);

	void init();
	void begin() {
		init();
	}
	void getFirmwareVersion(byte buf[]);

	byte irq_status(void);
};

#endif /* PN532_I2C_H_ */
